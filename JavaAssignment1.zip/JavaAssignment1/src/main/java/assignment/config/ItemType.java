package assignment.config;

public enum ItemType {
  RAW, MANUFACTURED, IMPORTED, NOT_ASSIGN
}
